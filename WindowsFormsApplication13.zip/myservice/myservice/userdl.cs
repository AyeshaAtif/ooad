﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace myservice
{
    public class userdl
    {
     public static List<myuser> users = new List<myuser>();
     public static List<admin> admins = new List<admin>();
    }
}