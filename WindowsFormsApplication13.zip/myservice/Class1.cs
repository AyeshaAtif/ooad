﻿using System;

public class Class1
{
	public Class1()
	{
        List<user> users = new List<user>();
	}
}
