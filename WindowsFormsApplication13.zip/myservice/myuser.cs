﻿using System;

public class Class1
{
	public Class1()
	{
        public static username;
        public static password;

	}
}
