﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication13
{
    public partial class adminlogin : Form
    {
        public adminlogin()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            adminreg r = new adminreg();
            r.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool isvalidadmins= false;
            bool isvaliduserpassed;
            server.Service1 myserver = new server.Service1();
            myserver.isvalidadmin(textBox1.Text, textBox2.Text, out isvalidadmins, out isvaliduserpassed);
            if (isvalidadmins)
            {
                MessageBox.Show("validuser");
                catagory_selection c = new catagory_selection();
                this.Hide();
                c.Show();
            }
            else
            {
                MessageBox.Show("invaliduser");
            }
        }
    }
}
